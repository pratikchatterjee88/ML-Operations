def red():
    print("You Choose Red Color")
    
def blue():
    print("You Choose Blue Color")
    
def green():
    print("You Choose Green Color")
    
def yellow():
    print("You Choose Yellow Color")
    
            
    