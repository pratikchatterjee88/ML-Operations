"""
Multiple Linear Regression - PRedict Continuous values
@author: tsecl
"""

# =============================================================================
# Import Libraries and Dataset
# =============================================================================
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

dataset = pd.read_csv("02Companies.csv")

# =============================================================================
# X & Y Feature Extraction
# =============================================================================
X = dataset.iloc[:,:-1]          # X Dataframe
y = dataset.iloc[:,4].values     # 1d array

# =============================================================================
# Convert State Column to Dummy variable
# =============================================================================
X = pd.get_dummies(X, columns=['State'], drop_first=True)

X = X.values   # Dataframe to Array


# =============================================================================
# Train-Test Split
# =============================================================================
from sklearn.model_selection import train_test_split
X_train,X_test, y_train,y_test = train_test_split(X,y, test_size=0.2, random_state=0)

# =============================================================================
# Model Implementation
# =============================================================================
from sklearn.linear_model import LinearRegression
regressor = LinearRegression()

regressor.fit(X_train,y_train)      # Machine Learns b0 and b1 values


print("slope/b0 ", regressor.coef_)
print("intercept/b1 ", regressor.intercept_)

# =============================================================================
# Model Testing
# =============================================================================
y_pred = regressor.predict(X_test)

from sklearn.metrics import mean_squared_error
mse = mean_squared_error(y_test,y_pred)  
rmse = np.sqrt(mse)  