# -*- coding: utf-8 -*-
"""
Created on Tue Sep 13 14:44:17 2022
Simple Linear Regression - Predict continuous values
@author: tsecl
"""

# =============================================================================
# Import Libraries and Dataset
# =============================================================================
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

dataset = pd.read_csv("01HR_Data.csv")

# =============================================================================
# X & Y Feature Extraction
# =============================================================================
X = dataset.iloc[:,[0]].values   # 2d matrix
y = dataset.iloc[:,1].values     # 1d array

# =============================================================================
# Train-Test Split
# =============================================================================
from sklearn.model_selection import train_test_split
X_train,X_test, y_train,y_test = train_test_split(X,y, test_size=1/3, random_state=0)

# =============================================================================
# Model Implementation
# =============================================================================
from sklearn.linear_model import LinearRegression
regressor = LinearRegression()

regressor.fit(X_train,y_train)      # Machine Learns b0 and b1 values


print("slope/b0 ", regressor.coef_)
print("intercept/b1 ", regressor.intercept_)


# =============================================================================
# Model Testing
# =============================================================================
y_pred = regressor.predict(X_test)

from sklearn.metrics import mean_squared_error
mse = mean_squared_error(y_test,y_pred)
rmse = np.sqrt(mse)

# =============================================================================
# Add on visualization
# =============================================================================
## plot testing data
plt.scatter(X_test,y_test, color='blue')
plt.plot(X_test,y_pred, color='red')


## plot training data
plt.scatter(X_train,y_train, color='blue')
plt.plot(X_train,regressor.predict(X_train), color='red')














