# -*- coding: utf-8 -*-
"""
Created on Fri Mar 17 11:49:39 2023

@author: tsecl
dog.1.jpg
"""


from tensorflow.keras.preprocessing import image

test_image = image.load_img(r'D:\HP-Desktop\MyDesktop\DataScience_ML\CollinsAeroSpace\Day5\dog.1.jpg')

%matplotlib inline
import matplotlib.pyplot as plt
plt.imshow(test_image)

# we are going send this image to CNN trained on (64,64) size

test_image64 = image.load_img(r'D:\HP-Desktop\MyDesktop\DataScience_ML\CollinsAeroSpace\Day5\dog.1.jpg',
                              target_size=(64,64))
%matplotlib inline
import matplotlib.pyplot as plt
plt.imshow(test_image64)