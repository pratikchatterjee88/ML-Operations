# -*- coding: utf-8 -*-
"""
@author: TSE
"""

import requests
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os

import pickle

def predOut(YrsExp):    
    model = pickle.load(open(r'D:\HP-Desktop\MyDesktop\DataScience_ML\CollinsAeroSpace\Day5\MLMat\linearModel.pkl','rb'))
    prediction = model.predict([[YrsExp]])   
    return prediction[0]
	
	
from flask import Flask, render_template,request
app = Flask(__name__)

@app.route('/')
def home():
    form=request.form
    return render_template('test.html',form=form)
	
@app.route('/hello', methods=['POST'])
def hello():    
    
   inputYrs = float(request.form['yrs_exp'])
   output= predOut(inputYrs)
   return render_template('test.html',output=output,name = "ML Application")

if __name__ == '__main__':
    app.run(debug=True)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
