# -*- coding: utf-8 -*-
"""
Created on Wed Mar 15 17:06:04 2023
Logistic Function
@author: tsecl
"""




import numpy as np

def sigmoid(x):
    return 1/(np.exp(-x)+1)


inputData = np.arange(-5.0,5.0,0.1)

y_output = sigmoid(inputData)

import matplotlib.pyplot as plt

plt.plot(y_output,marker='o')